import os
import boto3
import logging
import json

from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

_c2_client = boto3.resource('ec2')

def get_ec2_instances(region, instance_id):
    ec2_instance = _c2_client.Instance(instance_id)

    return ec2_instance

def start_ec2_instance(region, instance_id):
    instance = get_ec2_instances(region, instance_id)

    try:
        response = instance.start()
        print(response)
        return True
    except ClientError as e:
        print(e)
        return False

def stop_ec2_instance(region, instance_id):
    instance = get_ec2_instances(region, instance_id)

    try:
        response = instance.stop()
        print(response)
        return True
    except ClientError as e:
        print(e)
        return False

def build_response(state, type):
    response = ""

    if(state):
        responseBody = {
            "message": "Successfully invoked Start EC2 instance"
        };

        response = {
            "statusCode": 200,
            "body": json.dumps({"message": "Successfully invoked " + type + " EC2 instance"}),
            "isBase64Encoded": False
        };
    else:
        response = {
            "statusCode": 500,
            "body": json.dumps({"message": "Failed to invoke " + type + " EC2 instance"}),
            "isBase64Encoded": False
        };

    return response

def lambda_handler(event, context):
    # when invoked by api gateway params will be located in queryStringParameters
    event_params = event.get('queryStringParameters') or event

    region = event_params.get('region')
    instance_id = event_params.get('instanceId')
    state = False

    if(event_params.get('action') == 'start'):
        state = start_ec2_instance(region, instance_id)
        return build_response(state, 'start')
    elif(event_params.get('action') == 'stop'):
        state = stop_ec2_instance(region, instance_id)
        return build_response(state, 'stop')
    else:
        error_response = {
            "statusCode": 500,
            "body": json.dumps({"message": "Invalid action type"}),
            "isBase64Encoded": False
        };
        return error_response
