import os
import boto3
import logging

from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

_c2_client = boto3.resource('ec2')

def get_ec2_instances(region, instance_id):
    ec2_instance = _c2_client.Instance(instance_id)
    
    return ec2_instance

def start_ec2_instance(region, instance_id):
    instance = get_ec2_instances(region, instance_id)

    try:
        response = instance.stop()
        print(response)
        return True
    except ClientError as e:
        print(e)
        return False

def stop_ec2_instance(region, instance_id):
    instance = get_ec2_instances(region, instance_id)
    
    try:
        response = instance.stop()
        print(response)
        return True
    except ClientError as e:
        print(e)
        return False

def lambda_handler(event, context):
    region = event.get('region')
    instance_id = event.get('instanceId')
    state = False
    
    if(event.get('action') == 'start'):
        state = start_ec2_instance(region, instance_id)
    elif(event.get('action') == 'stop'):
        state = stop_ec2_instance(region, instance_id)
    
    return state
